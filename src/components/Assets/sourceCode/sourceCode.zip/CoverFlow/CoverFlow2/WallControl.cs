﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace DC.ControlLibrary
{
    public class WallControl : ItemsControl
    {
        public WallControl()
        {
            //DefaultStyleKey = typeof(WallControl);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if(e.Key ==Key.Right)
            {
                Next();
                e.Handled = true;
                return;
            }
            else if(e.Key == Key.Left)
            {
                Previous();
                e.Handled = true;
                return;
            }
            else if (e.Key == Key.Down)
            {
                SkipNext();
                e.Handled = true;
                return;
            }



            base.OnKeyDown(e);
        }

        public void Next()
        {
            //if (SelectedIndex < Items.Count - 1)
            //    SelectedIndex++;
        }

        public void Previous()
        {
            //if (SelectedIndex > 0)
            //    SelectedIndex--;
        }

        public void SkipNext()
        {
            ItemsPanelTemplate pt = this.ItemsPanel;
            var x = this.FindName("wrapPanel");
        }
    }
}
