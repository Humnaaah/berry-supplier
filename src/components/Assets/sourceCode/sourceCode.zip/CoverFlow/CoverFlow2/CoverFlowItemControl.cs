﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace DC.ControlLibrary
{
    public class CoverFlowItemControl : ContentControl
    {
        public PlaneProjection PlaneProjection { get; set; }
        public ScaleTransform ScaleTransform { get; set; }
        public TranslateTransform TranslateTransform { get; set; }

        public double XOffset 
        {
            get
            {
                if (ActualWidth > 0)
                    return ActualWidth / 2;
                else
                    return 0;
            }
        }

        public CoverFlowItemControl()
        {
            DefaultStyleKey = typeof(CoverFlowItemControl);
        }

        public override void OnApplyTemplate()
        {
            PlaneProjection = (PlaneProjection)GetTemplateChild("Rotator");
            ScaleTransform = (ScaleTransform)GetTemplateChild("scaleTransform");
            TranslateTransform = (TranslateTransform)GetTemplateChild("translateTransform");
        }
    }
}
