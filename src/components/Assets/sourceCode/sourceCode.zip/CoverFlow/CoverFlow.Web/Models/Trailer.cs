﻿namespace CoverFlow.Web.Models
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    namespace CoverFlow.Web.Models
    {
        [XmlRoot("records")]
        public class MovieTrailers
        {
            [XmlElementAttribute("movieinfo")]
            public List<Trailer> Trailers { get; set; }
        }

        [XmlType("movieinfo")]
        public class Trailer
        {
            [XmlAttribute("id")]
            public int Id { get; set; }
            [XmlElementAttribute("info")]
            public Info Info { get; set; }
            [XmlElementAttribute("cast")]
            public Cast Cast { get; set; }
            [XmlElementAttribute("genre")]
            public Genres Genres { get; set; }
            [XmlElementAttribute("poster")]
            public Poster Poster { get; set; }
            [XmlElementAttribute("preview")]
            public Preview Preview { get; set; }
        }

        public class Info
        {
            [XmlElement("title")]
            public string Title { get; set; }
            [XmlElement("runtime")]
            public string Runtime { get; set; }
            [XmlElement("rating")]
            public string Rating { get; set; }
            [XmlElement("studio")]
            public string Studio { get; set; }
            [XmlElement("postdate")]
            public string PostDateString { get; set; }
            public DateTime? PostDate
            {
                get
                {
                    DateTime d;
                    if (string.IsNullOrEmpty(PostDateString) || !DateTime.TryParse(PostDateString, out d))
                        return null;
                    return d;
                }
            }
            [XmlElement("releasedate")]
            public string ReleaseDateString { get; set; }
            public DateTime? ReleaseDate
            {
                get
                {
                    DateTime d;
                    if (string.IsNullOrEmpty(ReleaseDateString) || !DateTime.TryParse(ReleaseDateString, out d))
                        return null;
                    return d;
                }
            }
            [XmlElement("copyright")]
            public string Copyright { get; set; }
            [XmlElement("director")]
            public string Director { get; set; }
            [XmlElement("description")]
            public string Description { get; set; }
        }

        public class Cast
        {
            [XmlElementAttribute("name")]
            public List<string> Names { get; set; }
        }

        public class Genres
        {
            [XmlElementAttribute("name")]
            public List<string> Names { get; set; }
        }

        public class Poster
        {
            [XmlElement("location")]
            public string Location { get; set; }
            [XmlElement("xlarge")]
            public string ExtraLarge { get; set; }
        }
        public class Preview
        {
            [XmlElement("large")]
            public Large Large { get; set; }
        }
        public class Large
        {
            [XmlAttribute("filesize")]
            public long Filesize { get; set; }
            [XmlText]
            public string Value { get; set; }
        }
    }
}