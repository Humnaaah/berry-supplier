﻿using System.Net;
using System.Web.Mvc;

namespace CoverFlow.Web.Controllers
{
    public class TrailersController : Controller
    {
        //
        // GET: /Trailers/
        [OutputCache(Duration = 86400, VaryByParam = "none")]
        public ActionResult Index()
        {
            WebClient webClient = new WebClient();
            string xml = webClient.DownloadString("http://www.apple.com/trailers/home/xml/current.xml");
            return Content(xml, "text/xml");
        }
        //http://trailers.apple.com/trailers/home/xml/current_720p.xml
        //
    }
}
