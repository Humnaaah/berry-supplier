﻿using System;
using System.IO;
using System.Net;
using System.Web.Caching;
using System.Web.Mvc;
using System.Xml.Serialization;
using CoverFlow.Web.Models.CoverFlow.Web.Models;

namespace CoverFlow.Web.Controllers
{
    public class Html5Controller : Controller
    {
        //
        // GET: /Html5/

        public ActionResult Index()
        {
            if (HttpContext.Cache["trailers"] == null)
            {
                WebClient webClient = new WebClient();
                string xml = webClient.DownloadString("http://www.apple.com/trailers/home/xml/current.xml");
                var serializer = new XmlSerializer(typeof(MovieTrailers));
                TextReader r = new StringReader(xml);
                var movieTrailers = (MovieTrailers)serializer.Deserialize(r);
                HttpContext.Cache.Insert("trailers", movieTrailers, null, Cache.NoAbsoluteExpiration, TimeSpan.FromDays(1));
            }

            var trailers = HttpContext.Cache["trailers"] as MovieTrailers;

            return View(trailers);
        }

    }
}
