﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Linq;
using System.Collections.Generic;

namespace CoverFlowClient
{
    public class MovieTrailer
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string SortTitle { get; set; }
        public string Runtime { get; set; }
        public string Rating { get; set; }
        public string Studio { get; set; }
        public DateTime? PostDate { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public string Director { get; set; }
        public string Description { get; set; }
        public string Genre { get; set; }
        public string ImageUrl { get; set; }
        public string PreviewUrl { get; set; }

        public List<string> Cast { get; set; }

        public MovieTrailer()
        {
            Cast = new List<string>();
        }

        public MovieTrailer(XElement xMovie): this()
        {
            ParseXML(xMovie);
        }

        private void ParseXML(XElement xMovie)
        {            

            DateTime temp;
            if (xMovie.Attribute("id") != null)
                Id = int.Parse(xMovie.Attribute("id").Value);

            if (xMovie.Element("info") != null)
            {
                XElement info = xMovie.Element("info");

                if (info.Element("title") != null)
                {
                    Title = info.Element("title").Value;
                    SortTitle = Title;
                    if (SortTitle.ToLower().StartsWith("the "))
                    {
                        SortTitle = SortTitle.Substring(4) + ", The";
                    }
                }
                if (info.Element("runtime") != null)
                    Runtime = info.Element("runtime").Value;

                if (info.Element("rating") != null)
                    Rating = info.Element("rating").Value;

                if (info.Element("studio") != null)
                    Studio = info.Element("studio").Value;

                if (info.Element("studio") != null)
                    Director = info.Element("director").Value;

                if (info.Element("postdate") != null)
                {
                    if (DateTime.TryParse(info.Element("postdate").Value, out temp))
                        PostDate = temp;
                }
                if (info.Element("releasedate") != null)
                {
                    if (DateTime.TryParse(info.Element("releasedate").Value, out temp))
                        ReleaseDate = temp;
                }
                
                if (info.Element("description") != null)
                    Description = info.Element("description").Value;
            }

            if (xMovie.Element("genre") != null)
            {
                foreach (XElement xGenre in xMovie.Element("genre").Descendants("name"))
                {
                    Genre = xGenre.Value;
                }
            }

            if (xMovie.Element("cast") != null)
            {
                foreach (XElement xCast in xMovie.Element("cast").Descendants("name"))
                {
                    Cast.Add(xCast.Value);
                }
            }
            if (xMovie.Element("poster") != null && xMovie.Element("poster").Element("location") != null)
            {
                ImageUrl = xMovie.Element("poster").Element("xlarge").Value;
            }

            if (xMovie.Element("preview") != null && xMovie.Element("preview").Element("large") != null)
            {
                PreviewUrl = xMovie.Element("preview").Element("large").Value.Replace("movies.apple.com","www.apple.com");
            }
            
        }  
    }
}
