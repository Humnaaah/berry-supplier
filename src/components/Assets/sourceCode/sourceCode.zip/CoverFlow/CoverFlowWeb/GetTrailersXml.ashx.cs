﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Net;


    /// <summary>
    /// Summary description for $codebehindclassname$
    /// </summary>
    public class GetTrailersXml : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {

            if (context.Cache["movieXml"] == null)
            {
                WebClient webClient = new WebClient();
                string xml = webClient.DownloadString("http://www.apple.com/trailers/home/xml/current.xml");
                context.Cache.Insert("movieXml", xml, null, DateTime.UtcNow.AddDays(1), TimeSpan.FromSeconds(0));

            }
            context.Response.ContentType = "text/xml";
            context.Response.Write(context.Cache["movieXml"].ToString());
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
