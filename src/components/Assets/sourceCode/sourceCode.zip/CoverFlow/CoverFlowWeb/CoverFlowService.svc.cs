﻿using System;
using System.IO;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Web;

namespace CoverFlowWeb
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class CoverFlowService
    {
        // Add [WebGet] attribute to use HTTP GET
        [WebGet(UriTemplate = "Trailers")]
        [OperationContract]
        public Stream GetTrailerXml()
        {
            HttpContext context = HttpContext.Current;
            byte[] data;
            if (context.Cache["movieData"] == null)
            {
                var webClient = new WebClient();
                data = webClient.DownloadData("http://www.apple.com/trailers/home/xml/current.xml");
                context.Cache.Insert("movieData", data, null, DateTime.UtcNow.AddDays(1), TimeSpan.FromSeconds(0));
            }
            else
                data = (byte[])context.Cache["movieData"];
            // Add your operation implementation here
            var stream = new MemoryStream(data);
            WebOperationContext.Current.OutgoingResponse.ContentType = "application/xml";
            return stream;
        }

        // Add more operations here and mark them with [OperationContract]
    }
}
