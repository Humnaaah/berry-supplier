﻿using CoverFlow.Client.ViewModels;

namespace CoverFlow.Client
{
    public partial class MainPage
    {
        public CoverFlowViewModel ViewModel { get; set; }

        public MainPage()
        {
            InitializeComponent();
            ViewModel = new CoverFlowViewModel();
            DataContext = ViewModel;
            Loaded += (s, e) => ViewModel.Load();
        }
    }
}
