﻿using System;
using System.Windows.Data;
using CoverFlow.Client.Models;

namespace CoverFlow.Client.Converters
{
    public class TitleConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var trailer = value as Trailer;
            return trailer == null ? null : string.Format("{0} ({1})", trailer.Info.Title, trailer.Info.Rating);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
