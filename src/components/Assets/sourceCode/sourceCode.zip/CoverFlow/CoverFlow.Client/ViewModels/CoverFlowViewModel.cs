﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using CoverFlow.Client.Models;

namespace CoverFlow.Client.ViewModels
{
    public class CoverFlowViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Trailer> _trailers;
        public ObservableCollection<Trailer> Trailers
        {
            get { return _trailers; }
            set { _trailers = value; RaisePropertyChanged("Trailers"); }
        }

        private Trailer _selectedTrailer;
        public Trailer SelectedTrailer
        {
            get { return _selectedTrailer; }
            set { _selectedTrailer = value; RaisePropertyChanged("SelectedTrailer"); }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get { return _isBusy; }
            set { _isBusy = value; RaisePropertyChanged("IsBusy"); }
        }

        public void Load()
        {
            var model = new DataModel();
            IsBusy = true;
            model.GetTrailers((trailers, error) =>
            {
                if (error != null)
                    MessageBox.Show("Error: " + error.Message);
                else
                {
                    Trailers = new ObservableCollection<Trailer>(trailers.OrderByDescending(t=>t.Info.PostDate));
                    SelectedTrailer = Trailers.FirstOrDefault();
                }
                IsBusy = false;
            });
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
