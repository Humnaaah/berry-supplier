**Project Description**
Cover flow implemented in Silverlight 3.


I wanted to start getting into Silverlight 3 and learn more about extending the ItemsControl.  So, I decided to do a cover flow control (there are surprising few out there).  I've uploaded the source and can be downloaded in the downloads section and a live example can be viewed [here](http://coverflow.darickcarpenter.net/). 

I tried to make if fairly robust.  It can take any controls by using the data template (which must be done for now, I haven't implement a DisplayMemberPath yet).  Also the layout is pretty flexible and offers control over the following:

* Space between items
* Space between the selected item and the other items
* The angle non selected items are at
* The the depth of non selected items
* The scale of non selected items (depth and scale offer very similar effects, but are slightly different)
* The duration it take to switch selected items
* the easing function of the animations

All of these items can be changed dynamically as shown in the example.  Items can also be switch by next, previous, next page, previous page, first, last, or by clicking on them.  The keyboard can also be used.  The arrow keys work (the cover flow slider needs to have focus for the arrow keys to work so I am using some of the alphabet keys [A,S,D,W,Q,E](A,S,D,W,Q,E) as well).

A few of the new Silverlight beta 3 things are:
* PlaneProjection
* Easing
* Element Data Binding (I think this one is pretty cool, all the sliders are bound this way)
* GPU Acceleration on media playback
* H264 high def video playback

A quick note about the GPU Acceleration.  I tried using this on the cover flow control, and it seemed to work until you scroll/flow down the list to far then it starts to freak out.  Maybe the silverlight people can look at this.  But if that can be fixed in the release version, that should speed things up quite a bit.

edit: As of v 0.2 it runs pretty smooth, unles there are a lot of items and you click on first/last and it is at the opposite end, then it will be choppier, but other than that, it should run pretty smooth. I tried it with almost 400 items and I didn't notice any difference that if there were 60.

The data is from Apple Quicktime movie trailers and so are the movie files being played.  I didn't spend much time on the actual viewing experience of the movie trailer since that wan't the purpose.

I welcome any feedback or any suggestion on how make this control better/faster.  This is my first ItemsControl so, there may be better ways of doing things. 


Version 0.02:
* Optimized the code so it runs much smoother, even with many items.

![](Home_coverflow.jpg)